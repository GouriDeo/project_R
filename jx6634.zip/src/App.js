import "./styles.css";
import { DisplayDifficulty } from "./components/DisplayDifficulty/DisplayDifficulty";

export default function App() {
  return (
    <div className="App">
      <DisplayDifficulty />
    </div>
  );
}
